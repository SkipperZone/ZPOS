@extends('app')
<?php $data = Session::all(); //print_r($data)?>
@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">{{trans('report-stock.reports')}} - {{trans('report-stock.stocks_report')}}</div>

				<div class="panel-body">
                <form method="GET" action="/reports/stock_items/search" id="mainform" target="_blank">
                 <table class="table table-bordered">
                    <tr>
                        <th colspan="4">Filter Gudang</th>
                    </tr>
                    <tr>
                        <td colspan="4">{!!Form::radio('option_group', 'all', true, array('id'=>'all', 'onclick'=>"ClearFields1();"));!!} {{ trans('report-stock.find_all')}}</td>
                    </tr>
                     <tr>
                        <td width="30%">{!!Form::radio('option_group', 'location', false, array('id'=>'location'));!!} {{ trans('report-stock.find_location')}}
                        </td>
                         <td >
                            {!! Form::text('location', Input::old('location'), array('class' => 'form-control input-sm', 'placeholder'=> 'Type location or code here !', 'id'=>'readLocation', 'data'=>'typeahead', 'autocomplete' => 'off', 'disabled'=>"disabled", 'required')) !!}
                        </td>
                        <td width="20%"></td>
                       
                    </tr>
                </table>
                <table class="table table-bordered">
                    <tr>
                        <th colspan="4">Filter Barang</th>
                    </tr>
                     <tr>
                        <td colspan="4">{!!Form::radio('option_items', 'all', true, array('id'=>'allitem','onclick'=>"ClearFields2();"));!!} {{ trans('report-stock.find_all')}}</td>
                    </tr>
                    <tr>
                        <td width="30%">{!!Form::radio('option_items', 'item_group', false, array('id'=>'group'));!!} {{ trans('report-stock.find_group')}}
                        </td>
                        <td >
                            {!! Form::text('group', Input::old('group'), array('class' => 'form-control input-sm', 'placeholder'=> 'Type group or code here !', 'id'=>'readGroup', 'data'=>'typeahead', 'autocomplete' => 'off', 'disabled'=>"disabled", 'required')) !!}
                        </td>
                        <td></td>
                      
                    </tr>   <tr>
                        <td>{!!Form::radio('option_items', 'items', false, array('id'=>'code'));!!} {{ trans('report-stock.find_items')}}
                        </td>
                        <td >
                            {!! Form::text('code', Input::old('code'), array('class' => 'form-control input-sm', 'placeholder'=> 'Scan item or type code here !', 'id'=>'readBarcode', 'data'=>'typeahead', 'autocomplete' => 'off', 'disabled'=>"disabled", 'required')) !!}
                        </td>
                        <td></td>
                      
                    </tr>    
                </table>
                {!! Form::submit('Search', array('class' => 'btn btn-primary', 'target'=>'blank')) !!}
               @if(count(Session::get('items')) > 0)
                <a type="button" class="btn btn-default" href="/reports/stock_items/print" target=_new>Cetak</a> @endif
                 </form>
                    {{-- <hr>
                    <div>Total All Item : {{ DB::table('items')->count() }} items</div>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>{{trans('report-stock.barcode')}}</th>
                                <th>{{trans('report-stock.item_name')}}</th>
                                <th>{{trans('report-stock.item_group')}}</th>
                                <th>{{trans('report-stock.item_location')}}</th>
                                <th>{{trans('report-stock.item_quantity')}}</th>
                                {{-- <td>&nbsp;</td> --}}
                        {{--     </tr>
                        </thead>
                        <tbody>
                        @foreach($invReport as $value)
                            <tr>
                                <td>{{ $value->barcode }}</td>
                                <td>{{ $value->item_name }}</td>
                                <td>{{ $value->kategori->name }}</td>
                                <td>{{ $value->location->name }}</td>
                                <td>{{ $value->quantity }} {{ $value->satuan_name->name }}</td>
                                {{-- <td>
                                    <a class="btn btn-small btn-info" href="#detailedstocks{{ $value->id }}" >{{trans('report-stock.detail')}}</a>
                                </td> --}}
                            
                        {{-- @endforeach --}}
                 {{--        </tbody>
                    </table> --}}
				 </div>
			</div>
		</div>
	</div>
</div>
@endsection