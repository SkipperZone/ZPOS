<?php

return [

	'list_employees' => 'List Employees',
	'new_employee' => 'New Employee',
	'person_id' => 'Person ID',
	'name' => 'Name',
	'email' => 'Email',
	'password' => 'Password',
	'confirm_password' => 'Confirm Password',
	'submit' => 'Submit',
	'edit' => 'Edit',
	'delete' => 'Delete',
	'update_employee' => 'Update Employee'

];
