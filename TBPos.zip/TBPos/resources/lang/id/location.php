<?php

return [

	'list_locations'	=> 'Daftar Gudang',
	'list_location_moving'	=> 'Daftar Mutasi Gudang',
	'new_location' 		=> 'Gudang Baru',
	'new_mutation' 		=> 'Mutasi Baru',
	'from_location'		=> 'Gudang Asal',
	'to_location' 		=> 'Gudang Tujuan',
	'location_id'		=> 'ID Gudang',
	'code'				=> 'Kode Gudang',
	'desc'				=> 'Keterangan',
	'name' 				=> 'Nama Gudang',
	'submit'			=> 'Submit',
	'Next'			=> 'Lanjut',
	'edit'				=> 'Ganti',
	'delete' 			=> 'Hapus',
	'update_location' 	=> 'Ganti Gudang',
	'date'				=> 'Tanggal',
	'remarks'			=> 'Keterangan',
	'no'				=> 'No. Bukti',
	'qty'				=> 'Jumlah',
	'quantity'			=> 'Jumlah Barang',
	'quantity_stock'	=> 'Jumlah Semua Stok',
	'barcode'			=> 'Barcode',
	'place'				=> 'Ketik No. Bukti disini !',
];
