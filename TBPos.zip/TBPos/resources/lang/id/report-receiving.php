<?php

return [

	'reports' => 'Laporan',
	'receivings_report' => 'Laporan Penerimaan',
	'grand_total' => 'TOTAL',
	'receiving_id' => 'ID Penerimaan',
	'date' => 'Tanggal',
	'items_received' => 'Barang Diterima',
	'received_by' => 'Diterima Oleh',
	'supplied_by' => 'Dipasok Oleh',
	'total' => 'Total',
	'payment_type' => 'Jenis Pembayaran',
	'comments' => 'Komentar',
	'detail' => 'Rincian',
	'item_id' => 'ID Barang',
	'item_name' => 'Nama Barang:',
	'item_received' => 'Barang Diterima',

];
