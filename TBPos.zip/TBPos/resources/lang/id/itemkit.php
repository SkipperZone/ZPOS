<?php

return [

	'item_kits'				=> 'Barang Paketan',
	'new_item_kit'			=> 'Paketan Baru',
	'item_kit_id' 			=> 'Paket ID',
	'item_kit_name'			=> 'Nama Paket',
	'cost_price' 			=> 'Harga Beli',
	'selling_price'			=> 'Harga Jual',
	'item_kit_description'	=> 'Keterangan',
	'search_item' 			=> 'Cari Barang:',
	'description' 			=> 'Keterangan',
	'quantity' 				=> 'Quantity',
	'profit' 				=> 'KEUNTUNGAN:',
	'item_id' 				=> 'ID Barang',
	'item_name' 			=> 'Nama Barang',
	'submit' 				=> 'Submit Paketan',

];
