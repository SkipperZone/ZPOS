<?php

return [

	'list_satuans'	=> 'Daftar Satuan',
	'new_satuan' 		=> 'Satuan Baru',
	'satuan_id'		=> 'ID Satuan',
	'code'		=> 'Kode Satuan',
	'desc'				=> 'Keterangan',
	'name' 				=> 'Nama Satuan',
	'submit'			=> 'Submit',
	'edit'				=> 'Ganti',
	'delete' 			=> 'Hapus',
	'update_satuan' 	=> 'Ganti Satuan',

];
