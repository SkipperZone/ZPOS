<?php

return [

	'list_suppliers'	=> 'Daftar Pemasok',
	'new_supplier'		=> 'Pemasok Baru',
	'company_name' 		=> 'Nama Perusahaan',
	'name' 	=> 'Nama',
	'email' 	=> 'Email',
	'phone_number' => 'Nomor Telepon',
	'avatar'		=> 'Foto',
	'choose_avatar' => 'Pilih Foto:',
	'address' => 'Alamat',
	'city' => 'Kota',
	'state' => 'Provinsi',
	'zip' => 'Kode Pos',
	'comments' => 'Komentar',
	'account' => 'Akun',
	'submit' => 'Submit',
	'edit' => 'Ganti',
	'delete' => 'Hapus',
	'update_supplier' => 'Ganti Pemasok',

];
