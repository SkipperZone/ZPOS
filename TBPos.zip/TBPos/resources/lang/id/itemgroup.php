<?php

return [

	'list_itemgroups'	=> 'Daftar Group Barang',
	'new_itemgroup' 		=> 'Group Barang Baru',
	'itemgroup_id'		=> 'ID Group Barang',
	'itemgroup_code'		=> 'Kode Group Barang',
	'desc'				=> 'Keterangan',
	'name' 				=> 'Nama Group Barang',
	'submit'			=> 'Submit',
	'edit'				=> 'Ganti',
	'delete' 			=> 'Hapus',
	'update_itemgroup' 	=> 'Ganti Group Barang',

];
