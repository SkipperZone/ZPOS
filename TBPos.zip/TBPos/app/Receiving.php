<?php

namespace ZPos;

use Illuminate\Database\Eloquent\Model;

class Receiving extends Model
{
    //
}
