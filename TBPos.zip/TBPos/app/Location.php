<?php

namespace ZPos;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    //
}
