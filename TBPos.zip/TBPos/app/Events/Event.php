<?php

namespace ZPos\Events;

abstract class Event
{
    //
}
